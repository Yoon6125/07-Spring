package com.peisia.mapper;

import java.util.List;

import com.peisia.dto.GuestDto;
import com.peisia.dto.MemberDto;
import com.peisia.dto.SerchDto;

public interface GuestMapper {
	public int getTotalPostCount();

	public int getTotalSerchPostCount(String searchWord);

	public List<GuestDto> getList(int limitIndex);

	public List<GuestDto> getSerchList(SerchDto sd);

	public GuestDto read(long bno);

	public void del(long bno);

	public void write(GuestDto dto);

	public void modify(GuestDto dto);

	public void getreg(MemberDto md);

	public String login(MemberDto md);

}
