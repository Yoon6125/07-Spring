package com.peisia.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import com.peisia.dto.GuestDto;
import com.peisia.dto.SearchDto;
import com.peisia.mapper.GuestMapper;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@Log4j
@Service
public class GuestServiceImpl implements GuestService {

	@Setter(onMethod_ = @Autowired)
	private GuestMapper mapper;

	@Override
	public Model getlist(int currentPage, String searchWord, Model model) {
		int listPerPage = 5;
		int blockPerPage = 3;
		int currentBlock = 1;
		int startBlock = 1;
		int endBlock = 1;
		int totalBlock = 1;
		int prevBlock = 1;
		int nextBlock = 1;

		int count;

		int limitIndex = (currentPage - 1) * listPerPage;

		if (searchWord == null || searchWord.equals("null")) {
			model.addAttribute("getlist", mapper.getlist(limitIndex));
			count = mapper.getCountPost();
			model.addAttribute("count", mapper.getCountPost());
		} else {
			SearchDto sd = new SearchDto();
			sd.setSearchWord(searchWord);
			sd.setLimitIndex(limitIndex);
			model.addAttribute("searchList", mapper.searchList(sd));
			count = mapper.getSearchPostCount(searchWord);
			model.addAttribute("count", mapper.getSearchPostCount(searchWord));
			model.addAttribute("searchWord", searchWord);

		}

		// 총 페이지 수 구하기

		int totalPage = 0;

		// 총 페이지 수 = 전체 글 수/ 페이지당 보여줄 글 수
		totalPage = (int) Math.ceil((double) count / listPerPage);
		model.addAttribute("totalPage", totalPage);
		model.addAttribute("blockPerPage", blockPerPage);

		// 블럭 총 수
		totalBlock = (int) Math.ceil((double) totalPage / blockPerPage);
		model.addAttribute("totalBlock", totalBlock);

		// 현재 페이지 번호 구하기
		currentBlock = (int) Math.ceil((double) currentPage / blockPerPage);
		model.addAttribute("currentBlock", currentBlock);

		// 블럭의 시작,끝 구하기
		startBlock = (currentBlock - 1) * blockPerPage + 1;
		endBlock = currentBlock * blockPerPage;

		// 예외처리 구문
		if (endBlock > totalPage) {
			endBlock = totalPage;
		}
		model.addAttribute("startBlock", startBlock);
		model.addAttribute("endBlock", endBlock);

		// 이전,다음 이동 처리
		if (currentBlock > 1) {
			model.addAttribute("hasBlockPrev", true);

			prevBlock = (currentBlock - 1) * blockPerPage;

			model.addAttribute("prevBlock", prevBlock);
		} else {
			model.addAttribute("hasBlockPrev", false);
		}

		// 다음 블럭 이동 여부
		if (currentBlock < totalBlock) {
			model.addAttribute("hasBlockNext", true);

			nextBlock = currentBlock * blockPerPage + 1;

			model.addAttribute("nextBlock", nextBlock);
		} else {
			model.addAttribute("hasBlockNext", false);
		}

		return model;
	}

	@Override
	public GuestDto read(long bno) {

		return mapper.read(bno);
	}

	@Override
	public void del(long bno) {
		mapper.del(bno);
	}

	@Override
	public void write(GuestDto dto) {
		mapper.write(dto);
	}

	@Override
	public void modify(GuestDto dto) {
		mapper.modify(dto);
	}

}
