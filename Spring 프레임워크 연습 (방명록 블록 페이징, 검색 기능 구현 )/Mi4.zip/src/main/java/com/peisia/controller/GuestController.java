package com.peisia.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.peisia.dto.GuestDto;
import com.peisia.service.GuestService;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@Log4j
@RequestMapping("/guest/*")
@Controller
@AllArgsConstructor
public class GuestController {
	private GuestService service;

	@GetMapping({ "/getList", "/getSearchList" })
	public void getList(HttpServletRequest request,
			@RequestParam(value = "currentPage", defaultValue = "1") int currentPage,
			@RequestParam(value = "searchWord", defaultValue = "null") String searchWord, Model model) {
		String path = request.getContextPath();
//		System.out.println(path);
		String keyword = request.getParameter("searchWord");
		System.out.println(keyword);
		model.addAttribute("blp", service.getList(currentPage, path, keyword));
	}

	@GetMapping("/read")
	public void read(@RequestParam("bno") long bno, Model model) {
		model.addAttribute("read", service.read(bno));
	}

	@GetMapping("/del")
	public String del(@RequestParam("bno") long bno) {
		service.del(bno);
		return "redirect:/guest/getList";
	}

	@GetMapping("/write")
	public void write() {

	}

	@PostMapping("/write")
	public String write(GuestDto dto) {
		service.write(dto);
		return "redirect:/guest/getList";
	}

	@PostMapping("/modify")
	public String modify(GuestDto dto) {
		service.modify(dto);
		return "redirect:/guest/getList";
	}

	@GetMapping("/modify")
	public void modifyread(@RequestParam("bno") long bno, Model model) {
		model.addAttribute("readmodify", service.read(bno));

	}

}
