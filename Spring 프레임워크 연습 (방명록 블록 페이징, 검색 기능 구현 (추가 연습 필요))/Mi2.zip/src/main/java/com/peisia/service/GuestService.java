package com.peisia.service;

import org.springframework.ui.Model;

import com.peisia.dto.GuestDto;
import com.peisia.dto.MemberDto;

public interface GuestService {
	public Model getList(int currentPage, String searchWord, Model model);

	public GuestDto read(long bno);

	public void del(long bno);

	public void write(GuestDto dto);

	public void modify(GuestDto dto);

	public void getreg(MemberDto md);

	public String login(MemberDto md);

}
