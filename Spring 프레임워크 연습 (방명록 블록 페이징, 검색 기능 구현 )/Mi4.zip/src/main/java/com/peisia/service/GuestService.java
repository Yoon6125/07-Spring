package com.peisia.service;

import com.peisia.dto.GuestDto;

public interface GuestService {
	public BoardListProcessor getList(int currentPage, String path, String searchWord);

	public GuestDto read(long bno);

	public void del(long bno);

	public void write(GuestDto dto);

	public void modify(GuestDto dto);

}
