package com.peisia.mapper;

public interface TestMapper {

}
