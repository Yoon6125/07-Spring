package com.peisia.controller;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.peisia.dto.GuestDto;
import com.peisia.dto.MemberDto;
import com.peisia.service.GuestService;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@Log4j
@RequestMapping("/guest/*")
@AllArgsConstructor
@Controller
public class GuestController {

	private GuestService service;

	@GetMapping({ "/getList", "/getSerchList" })
	public void getList(@RequestParam(value = "currentPage", defaultValue = "1") int currentPage,
			@RequestParam(value = "serchWord", defaultValue = "null") String serchWord, Model model) {

		model = service.getList(currentPage, serchWord, model);

	}

	@GetMapping({ "/read", "/modify" })
	public void read(@RequestParam("bno") Long bno, Model model) {
		log.info("컨트롤러 ==== 글번호 ===============" + bno);
		model.addAttribute("read", service.read(bno));
	}

	@GetMapping("/del")
	public String del(@RequestParam("bno") Long bno) {
		log.info("컨트롤러 ==== 글번호 ===============" + bno);
		service.del(bno);
		return "redirect:/guest/getList"; // 책 p.245 참고
	}

	@PostMapping("/write")
	public String write(GuestDto gvo) {
		service.write(gvo);
		return "redirect:/guest/getList"; // 책 p.245 참고
	}

	@GetMapping("/write") // 책 p.239 /write 중복이지만 이건 글쓰기 화면을 위한 url 매핑
	public void write() {

	}

	@PostMapping("/modify")
	public String modify(GuestDto gvo) {
		service.modify(gvo);
		return "redirect:/guest/getList";
	}

	@PostMapping("/getSearchList")
	public String returntoList(Model model, @RequestParam(value = "currentPage", defaultValue = "1") int currentPage,
			@RequestParam(value = "searchWord", defaultValue = "null") String searchWord) {

		return "redirect:/guest/getSearchList?currentPage=" + currentPage + "searchWord=" + searchWord;

	}

	@GetMapping("/getreg")
	public void getreg() {

	}

	@PostMapping("/getreg")
	public String getreg(MemberDto md) {
		service.getreg(md);
		return "redirect:/";
	}

	@GetMapping("/login")
	public void login() {

	}

	@GetMapping("/loginProc")
	public String loginProc(MemberDto md, HttpSession session, Model model) {
		session.setAttribute("loginid", service.login(md));
		System.out.println("---세션에 잘 전달됌");
		System.out.println("로그인한 아이디 :" + md.getBid());
		session.setAttribute("id", md.getBid());

		return "redirect:/";
	}

}
