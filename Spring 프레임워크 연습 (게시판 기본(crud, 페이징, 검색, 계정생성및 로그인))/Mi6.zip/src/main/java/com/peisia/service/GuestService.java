package com.peisia.service;

import com.peisia.dto.GuestDto;
import com.peisia.dto.MemberDto;

public interface GuestService {
	public BoardListProcessor getList(int currentPage, String path, String SearchWord);

	public GuestDto read(long bno);

	public void del(long bno);

	public void write(GuestDto dto);

	public void modify(GuestDto dto);

	// 회원가입
	public void register(MemberDto md);

	// 로그인
	public String login(MemberDto md);

}
