package com.peisia.service;

import java.util.ArrayList;

import com.peisia.dto.GuestDto;
import com.peisia.dto.SearchDto;
import com.peisia.mapper.GuestMapper;

import lombok.Data;

//페이징 처리 메소드
@Data
public class BoardListProcessor {
	private GuestMapper mapper;
	private ArrayList<GuestDto> post;
	public int totalPage = 0;
	public int currentPage = 1;
	private String htmlPageList;

	// 페이징 블럭 처리
	// 1-9 블럭 총 갯수 구하기
	int totalBlock = 0; // 블럭 총 개수

	// 2-9 현재 블럭 구하기
	int currentBlockNo = 0;

	// 3-9 블럭 시작 페이지 번호 구하기
	int blockStartNo = 0;

	// 4-9 블럭 끝 페이지 번호 구하기
	int blockEndNo = 0;

	// 5-9 이전/다음 관련 초기화 처리
	int prevPage = 0;
	int nextPage = 0;

	// 6-9 이전/다음 관련 계산 처리
	boolean hasPrev = true;
	boolean hasNext = true;

	// 페이징 블럭 메소드 선언
	public BoardListProcessor(GuestMapper mapper, String searchWord, int currentPage, String path) {
		super();
		this.mapper = mapper;
		this.currentPage = currentPage;
		this.totalPage = 0;
//		System.out.println("boardprocessor 메소드에서 받은 단어:" + searchWord);
		if (searchWord == null || searchWord.equals("null")) {
			totalPage = getPageCount();
			System.out.println(totalPage);
			getList();
		} else {
//			System.out.println("boardprocessor 메소드에서 조건문에 받은 단어:" + searchWord);
			totalPage = getSearchPageCount(searchWord);
//			System.out.println("조건문 타고 getSearchPageCount 실행후 페이지수:" + totalPage);
			getSearchList(searchWord);
		}

		// 블럭 처리 , 블럭의 총 갯수 구하기
		totalBlock = (int) Math.ceil((double) totalPage / 5);

		// 블럭 처리 , 현재 블럭 구하기
		currentBlockNo = (int) Math.ceil((double) this.currentPage / 5);

		// 블럭 처리, 블럭 시작 페이지 번호 구하기
		blockStartNo = (currentBlockNo - 1) * 5 + 1;

		// 블럭 처리, 블럭 끝 페이지 번호 구하기
		blockEndNo = currentBlockNo * 5;

		// 블럭 마지막 번호가 전체 페이지 번호보다 클시 예외처리 구문
		if (blockEndNo > totalPage) {
			blockEndNo = totalPage;
		}

		// 이전/다음 관련 계산 처리
		// 현재 블럭에서 이전/다음 이 가능하니 계산하고 가능 여부 저장
		if (currentBlockNo == 1) {
			hasPrev = false;
		} else {
			hasPrev = true;

			// 이전 블럭 이동시 몇 페이지로 이동할지 정하기
			// 이전 블럭의 마지막 페이지로 이동하게, 공식:(현재 블럭 -1)* 블럭당 페이지 수
			prevPage = (currentBlockNo - 1) * 5;
		}

		if (currentBlockNo < totalBlock) {
			hasNext = true;

			// 다음 블럭 이동시 몇 페이지로 이동할지 정하기
			// 다음 블럭의 첫 페이지로 이동하는게 많으니 그렇게 구현, 공식: 현재 블럭 번호 *블럭당 페이지 수+1

			nextPage = currentBlockNo * 5 + 1;
		} else {
			hasNext = false;
		}

		this.htmlPageList = getHtmlPageList(path, searchWord);
	}

	// 리스트 가져오는 메소드 선언
	public void getList() {
		int startIndex = (currentPage - 1) * 5;
		post = mapper.getList(startIndex);
	}

	// 리스트 가져오는 메소드 (검색)
	public void getSearchList(String searchWord) {
		int startIndex = (currentPage - 1) * 5;
		SearchDto dto = new SearchDto();
		dto.setLimitIndex(startIndex);
		dto.setSearchWord(searchWord);
		post = mapper.getSearchList(dto);
	}

	// 총 페이지 수 구하기
	public int getPageCount() {
		int totalPageCount = 0;
		int count = mapper.getCount();
		if (count % 5 == 0) {
			totalPageCount = count / 5;
		} else {
			totalPageCount = count / 5 + 1;
		}
		return totalPageCount;
	}

	// 총 페이지 수(검색용)
	public int getSearchPageCount(String searchWord) {
		int totalPageCount = 0;
		int count = mapper.getSearchCount(searchWord);
		if (count % 5 == 0) {
			totalPageCount = count / 5;
		} else {
			totalPageCount = count / 5 + 1;
		}
		return totalPageCount;
	}

	// 글 리스트 객체 얻는 함수
	public ArrayList<GuestDto> getPosts() {
		return post;
	}

	// 글 리스트 객체 얻는 함수(검색용)
	public ArrayList<GuestDto> getSearchPosts(SearchDto dto) {
		return post;
	}

	// 페이지 리스트를 출력하기 위한 html 리턴 메소드
	public String getHtmlPageList(String path, String searchWord) {
		StringBuilder html = new StringBuilder();

		// 이전 블록 이동 링크 생성
		if (hasPrev) {
			if (searchWord == null || searchWord.equals("null")) {
				html.append(String.format("<a href='%s/guest/getList?currentPage=%d'>이전</a>", path, prevPage));
			} else {
				html.append(String.format("<a href='%s/guest/getSearchList?currentPage=%d&searchWord=%s'>이전</a>", path,
						prevPage, searchWord));
			}
		}

		// 현재 블록의 페이지 링크 생성
		for (int i = blockStartNo; i <= blockEndNo; i++) {
			if (searchWord == null || searchWord.equals("null")) {
				html.append(String.format("<a href='%s/guest/getList?currentPage=%d'>%d</a>&nbsp;&nbsp;", path, i, i));
			} else {
				html.append(String.format(
						"<a href='%s/guest/getSearchList?currentPage=%d&searchWord=%s'>%d</a>&nbsp;&nbsp;", path, i,
						searchWord, i));
			}
		}

		// 다음 블록 이동 링크 생성
		if (hasNext) {
			if (searchWord == null || searchWord.equals("null")) {
				html.append(String.format("<a href='%s/guest/getList?currentPage=%d'>다음</a>", path, nextPage));
			} else {
				html.append(String.format("<a href='%s/guest/getSearchList?currentPage=%d&searchWord=%s'>다음</a>", path,
						nextPage, searchWord));
			}
		}

		return html.toString();
	}

}
