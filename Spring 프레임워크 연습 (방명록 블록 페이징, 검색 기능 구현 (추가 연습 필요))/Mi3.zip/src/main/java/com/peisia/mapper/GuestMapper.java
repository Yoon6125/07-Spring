package com.peisia.mapper;

import java.util.List;

import com.peisia.dto.GuestDto;
import com.peisia.dto.SearchDto;

public interface GuestMapper {
	public int getCountPost();

	public int getSearchPostCount(String searchWord);

	public List<GuestDto> getlist(int limitIndex);

	public List<GuestDto> searchList(SearchDto sd);

	public GuestDto read(long bno);

	public void del(long no);

	public void write(GuestDto dto);

	public void modify(GuestDto dto);
}
