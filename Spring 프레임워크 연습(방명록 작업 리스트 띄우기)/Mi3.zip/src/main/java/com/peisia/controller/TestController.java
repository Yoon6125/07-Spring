package com.peisia.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.peisia.service.TestService;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@Log4j
@RequestMapping("/test/*")
//@AllArgsConstructor
@Controller
public class TestController {
	@Setter(onMethod_ = @Autowired)
	private TestService service;

	@GetMapping("/getOnePlusTwo")
	// public void getOnePlusTwo() {
	public void getOnePlusTwo(Model model) {
		String one = service.getOne();
		String two = service.getTwo();

		Integer sum = Integer.parseInt(one) + Integer.parseInt(two);
		log.info("(컨트롤러 테스트) 1덩하기 2는 =" + sum);

		model.addAttribute("sum", sum);
	}

}
