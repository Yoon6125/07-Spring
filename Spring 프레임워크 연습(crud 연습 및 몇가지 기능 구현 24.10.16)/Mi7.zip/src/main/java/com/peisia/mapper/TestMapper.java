package com.peisia.mapper;

import com.peisia.spring.dto.TestDto;

public interface TestMapper {
	public TestDto dto1();

	public TestDto dto2();

	public TestDto dto3();

	public TestDto dto4();

}
