package com.peisia.service;

public interface TestService {
	public String getOne();

	public String getTwo();

}
