package com.peisia.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import com.peisia.dto.GuestDto;
import com.peisia.dto.MemberDto;
import com.peisia.dto.SerchDto;
import com.peisia.mapper.GuestMapper;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@Log4j
@Service
//@AllArgsConstructor
public class GuestServiceImpl implements GuestService {

	@Setter(onMethod_ = @Autowired)
	private GuestMapper mapper;

	@Override
	public Model getList(int currentPage, String serchWord, Model model) {
		int listPerPage = 5; // 페이지 1개당 글 개수 표시
		int pagePerBlock = 3;// 블럭당 페이지 수
		int currentBlock = 1; // 현제 페이지 블럭 추후에 조건문으로 1로 초기화
		int blockStartPage = 1; // 블럭 시작 페이지
		int blockEndPage = 1; // 블럭 끝 페이지
		int blockCount = 1; // 블럭 총 갯
		int prevPage = 1; // 이전 블럭 링크 클릭에 걸 페이지
		int nextPage = 1; // 다음 블럭 링크 클릭에 걸 페이지
		int count;

		log.info("비지니스 계층===========");
		int limitIndex = (currentPage - 1) * listPerPage;

		if (serchWord == null || serchWord.equals("null")) {
			model.addAttribute("list", mapper.getList(limitIndex));
			count = mapper.getTotalPostCount();
			model.addAttribute("count", mapper.getTotalPostCount());
		} else {
			SerchDto sd = new SerchDto();
			sd.setSerchWord(serchWord);
			sd.setLimitIndex(limitIndex);
			model.addAttribute("Serchlist", mapper.getSerchList(sd));
			count = mapper.getTotalSerchPostCount(serchWord);
			model.addAttribute("count", mapper.getTotalSerchPostCount(serchWord));
			model.addAttribute("serchWord", serchWord);
		}
		System.out.println("+++++++++++++++++++++++++++++++++++++검색어" + serchWord);

		// 총 페이지 수 구하기
		int totalPageCount = 0;

		// 총 페이지수 = 전체 글 수/ 페이지당 보여줄 글 수
		totalPageCount = (int) Math.ceil((double) count / listPerPage);
		log.info("=====방명록===== : 총 게시글 수는 " + count);
		log.info("=====방명록===== : 총 페이지 수는 " + totalPageCount);

		model.addAttribute("totalPageCount", totalPageCount);
		// 블럭당 페이지 수 전달
		model.addAttribute("pagePerBlock", pagePerBlock);

		// 블럭 총 수
		blockCount = (int) Math.ceil((double) totalPageCount / pagePerBlock);
		model.addAttribute("blockCount", blockCount);

		// 현제 페이지 번호로 현재 블럭 번호 구하기
		// 공식 : 현재 블럭번호 = 현재 페이지 번호 / 블럭 당 페이지 수 << 후 올림 처리
		currentBlock = (int) Math.ceil((double) currentPage / pagePerBlock);
		model.addAttribute("currentBlock", currentBlock);

		// 블럭 시작, 끝 페이지 구하기
		blockStartPage = (currentBlock - 1) * pagePerBlock + 1;
		blockEndPage = currentBlock * pagePerBlock;

		// 예외처리 , 마지막 페이지 보다 크면 마지막 페이지 값 전달
		if (blockEndPage > totalPageCount) {
			blockEndPage = totalPageCount;
		}
		model.addAttribute("blockStartPage", blockStartPage);
		model.addAttribute("blockEndPage", blockEndPage);

		// 이전 블럭 이동 가능 여부
		if (currentBlock > 1) {
			model.addAttribute("hasBlockPrev", true);
			// 이전 블럭 링크 클릭에 걸 페이지 계산 처리
			prevPage = (currentBlock - 1) * pagePerBlock;
			model.addAttribute("prevPage", prevPage);
		}
		// 다음 블럭 이동 가능 여부
		if (currentBlock < blockCount) {
			model.addAttribute("hasBlockNext", true);
			// 다음 블럭 링크 를긱에 걸 페이지 계산 처리
			nextPage = currentBlock * pagePerBlock + 1;
			model.addAttribute("nextPage", nextPage);
		}

		return model;
	}

	@Override
	public GuestDto read(long bno) {
		return mapper.read(bno);
	}

	@Override
	public void del(long bno) {
		mapper.del(bno);
	}

	@Override
	public void write(GuestDto dto) {
		mapper.write(dto);
	}

	@Override
	public void modify(GuestDto dto) {
		mapper.modify(dto);
	}

	@Override
	public void getreg(MemberDto md) {
		mapper.getreg(md);
	}

	@Override
	public String login(MemberDto md) {

		return mapper.login(md);
	}
}
