package com.peisia.dto;

import lombok.Data;

@Data
public class SearchDto {
	private int limitIndex;
	private String searchWord;

}
