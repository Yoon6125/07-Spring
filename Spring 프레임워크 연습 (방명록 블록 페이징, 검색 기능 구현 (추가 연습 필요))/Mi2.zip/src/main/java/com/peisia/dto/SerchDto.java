package com.peisia.dto;

import lombok.Data;

@Data
public class SerchDto {
	private String serchWord;
	private int limitIndex;
}
