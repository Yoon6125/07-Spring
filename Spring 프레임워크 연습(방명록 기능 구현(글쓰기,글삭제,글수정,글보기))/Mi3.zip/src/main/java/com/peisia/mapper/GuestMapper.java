package com.peisia.mapper;

import java.util.ArrayList;

import com.peisia.dto.GuestDto;

public interface GuestMapper {
	public ArrayList<GuestDto> list();

	public GuestDto read(long bno);

	public void del(long no);

	public void write(GuestDto dto);

	public void modify(GuestDto dto);
}
